/**
 * API Service - Improved version with better error handling and type safety
 */

import { STORAGE_KEYS, UI_CONFIG, ERROR_MESSAGES } from '../constants';
import type {
  EventResponse,
  NotificationResponse,
  HomeTasksResponse,
  MeResponse,
  CircleSummary,
  CircleMemberResponse,
  EventCommentResponse,
  EventNoteResponse,
  CreateEventPayload,
  UpdateEventStatusPayload,
  AddCircleMemberPayload,
  CreateEventCommentPayload,
  CreateEventNotePayload,
  UploadVideoResponse,
} from '../types';

const API_BASE_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:3000/api';
const API_ORIGIN = API_BASE_URL.replace(/\/api\/?$/, '');

/**
 * Convert relative URL to absolute media URL
 */
export function toMediaUrl(url?: string): string {
  if (!url) return '';
  if (url.startsWith('http://') || url.startsWith('https://')) return url;
  if (url.startsWith('/')) return `${API_ORIGIN}${url}`;
  return `${API_ORIGIN}/${url}`;
}

/**
 * Get user ID from localStorage
 */
export function getUserId(): string | null {
  if (typeof window === 'undefined' || !window.localStorage) return null;
  return window.localStorage.getItem(STORAGE_KEYS.USER_ID);
}

/**
 * Set user ID in localStorage
 */
export function setUserId(userId: string | null): void {
  if (typeof window === 'undefined' || !window.localStorage) return;

  if (!userId) {
    window.localStorage.removeItem(STORAGE_KEYS.USER_ID);
    return;
  }

  window.localStorage.setItem(STORAGE_KEYS.USER_ID, userId);
}

/**
 * Core fetch wrapper with error handling
 */
async function apiFetch<T>(path: string, init: RequestInit = {}): Promise<T> {
  const userId = getUserId();

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), UI_CONFIG.API_TIMEOUT);

  try {
    const response = await fetch(`${API_BASE_URL}${path}`, {
      ...init,
      signal: controller.signal,
      headers: {
        ...(init.headers ?? {}),
        ...(userId ? { 'x-user-id': userId } : {}),
      },
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      const text = await response.text().catch(() => '');
      throw new Error(`${response.status} ${response.statusText}${text ? ` - ${text}` : ''}`);
    }

    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      return (await response.text()) as T;
    }

    return (await response.json()) as T;
  } catch (error) {
    clearTimeout(timeoutId);

    if (error instanceof Error) {
      if (error.name === 'AbortError') {
        throw new Error(ERROR_MESSAGES.NETWORK);
      }
    }

    throw error;
  }
}

// ============ User APIs ============

export async function getMe(): Promise<MeResponse> {
  return apiFetch<MeResponse>('/users/me');
}

// ============ Home/Dashboard APIs ============

export async function getHomeTasks(): Promise<HomeTasksResponse> {
  return apiFetch<HomeTasksResponse>('/home/tasks');
}

// ============ Events APIs ============

export async function getEvents(circleId: string): Promise<EventResponse[]> {
  const params = new URLSearchParams({ circleId });
  return apiFetch<EventResponse[]>(`/events?${params.toString()}`);
}

export async function getEvent(id: string): Promise<EventResponse> {
  return apiFetch<EventResponse>(`/events/${id}`);
}

export async function createEventJson(payload: CreateEventPayload): Promise<EventResponse> {
  return apiFetch<EventResponse>('/events', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
}

export async function uploadVideo(file: File): Promise<UploadVideoResponse> {
  // Validate file
  if (file.size > UI_CONFIG.MAX_FILE_SIZE) {
    throw new Error(ERROR_MESSAGES.FILE_TOO_LARGE);
  }

  if (!UI_CONFIG.ALLOWED_VIDEO_TYPES.includes(file.type)) {
    throw new Error(ERROR_MESSAGES.INVALID_FILE_TYPE);
  }

  const formData = new FormData();
  formData.append('file', file);

  return apiFetch<UploadVideoResponse>('/upload/video', {
    method: 'POST',
    body: formData,
  });
}

export async function createEventMultipart(
  payload: CreateEventPayload,
  file?: File
): Promise<EventResponse> {
  const formData = new FormData();

  Object.entries(payload).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') {
      formData.append(key, String(value));
    }
  });

  if (file) {
    // Validate file
    if (file.size > UI_CONFIG.MAX_FILE_SIZE) {
      throw new Error(ERROR_MESSAGES.FILE_TOO_LARGE);
    }

    if (!UI_CONFIG.ALLOWED_VIDEO_TYPES.includes(file.type)) {
      throw new Error(ERROR_MESSAGES.INVALID_FILE_TYPE);
    }

    formData.append('file', file);
  }

  return apiFetch<EventResponse>('/events', {
    method: 'POST',
    body: formData,
  });
}

export async function createEvent(
  payload: CreateEventPayload,
  file?: File
): Promise<EventResponse> {
  if (!file) {
    return createEventJson(payload);
  }

  try {
    return await createEventMultipart(payload, file);
  } catch {
    const uploadResponse = await uploadVideo(file);
    return createEventJson({ ...payload, videoAssetId: uploadResponse.videoAssetId });
  }
}

export async function updateEventStatus(
  id: string,
  payload: UpdateEventStatusPayload
): Promise<EventResponse> {
  return apiFetch<EventResponse>(`/events/${id}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
}

// ============ Event Comments APIs ============

export async function getEventComments(eventId: string): Promise<EventCommentResponse[]> {
  return apiFetch<EventCommentResponse[]>(`/events/${eventId}/comments`);
}

export async function createEventComment(
  eventId: string,
  payload: CreateEventCommentPayload
): Promise<EventCommentResponse> {
  return apiFetch<EventCommentResponse>(`/events/${eventId}/comments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
}

// ============ Event Notes APIs ============

export async function getEventNotes(eventId: string): Promise<EventNoteResponse[]> {
  return apiFetch<EventNoteResponse[]>(`/events/${eventId}/notes`);
}

export async function createEventNote(
  eventId: string,
  payload: CreateEventNotePayload
): Promise<EventNoteResponse> {
  return apiFetch<EventNoteResponse>(`/events/${eventId}/notes`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
}

// ============ Circles APIs ============

export async function getCircles(): Promise<CircleSummary[]> {
  return apiFetch<CircleSummary[]>('/circles');
}

export async function getCircleMembers(circleId: string): Promise<CircleMemberResponse[]> {
  return apiFetch<CircleMemberResponse[]>(`/circles/${circleId}/members`);
}

export async function addCircleMember(
  circleId: string,
  payload: AddCircleMemberPayload
): Promise<CircleMemberResponse> {
  return apiFetch<CircleMemberResponse>(`/circles/${circleId}/members`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
}

export async function removeCircleMember(
  circleId: string,
  memberId: string
): Promise<{ success: boolean }> {
  return apiFetch<{ success: boolean }>(`/circles/${circleId}/members/${memberId}`, {
    method: 'DELETE',
  });
}

// ============ Notifications APIs ============

export async function getNotifications(params?: {
  unreadOnly?: boolean;
}): Promise<NotificationResponse[]> {
  const searchParams = new URLSearchParams();
  if (params?.unreadOnly) {
    searchParams.set('unreadOnly', 'true');
  }

  const query = searchParams.toString();
  return apiFetch<NotificationResponse[]>(`/notifications${query ? `?${query}` : ''}`);
}

export async function getUnreadNotificationCount(): Promise<{ unreadCount: number }> {
  return apiFetch<{ unreadCount: number }>('/notifications/unread-count');
}

export async function markNotificationRead(id: string): Promise<{ ok: boolean }> {
  return apiFetch<{ ok: boolean }>(`/notifications/${id}/read`, {
    method: 'PATCH',
  });
}

export async function markAllNotificationsRead(): Promise<{ ok: boolean }> {
  return apiFetch<{ ok: boolean }>('/notifications/mark-all-read', {
    method: 'POST',
  });
}

// ============ Health Check API ============

export async function health(): Promise<{
  ok: boolean;
  db: string;
  timestamp: string;
}> {
  return apiFetch('/health');
}
