/**
 * Application constants
 */

export const APP_CONFIG = {
  NAME: 'NeighborGuard',
  VERSION: '1.0.0',
  API_TIMEOUT: 30000,
} as const;

export const STORAGE_KEYS = {
  USER_ID: 'dev.currentUserId',
  THEME: 'app.theme',
  LANGUAGE: 'app.language',
} as const;

export const ROUTES = {
  HOME: '/',
  LOGIN: '/login',
  CIRCLE_DASHBOARD: (id: string) => `/circles/${id}`,
  CIRCLE_EVENTS: (id: string) => `/circles/${id}/events`,
  EVENT_DETAIL: (id: string) => `/events/${id}`,
} as const;

export const EVENT_TYPES = {
  SUSPICIOUS_PERSON: 'suspicious_person',
  PACKAGE_DELIVERY: 'package_delivery',
  NOISE_COMPLAINT: 'noise_complaint',
  MAINTENANCE: 'maintenance',
  SECURITY_CONCERN: 'security_concern',
  OTHER: 'other',
} as const;

export const CAMERA_ZONES = {
  FRONT_DOOR: 'front-door',
  BACK_DOOR: 'back-door',
  GARAGE: 'garage',
  DRIVEWAY: 'driveway',
  BACKYARD: 'backyard',
  STREET: 'street',
  OTHER: 'other',
} as const;

export const EVENT_SEVERITIES = {
  LOW: 'low',
  MEDIUM: 'medium',
  HIGH: 'high',
} as const;

export const EVENT_STATUSES = {
  OPEN: 'open',
  RESOLVED: 'resolved',
} as const;

export const MEMBER_ROLES = {
  OWNER: 'owner',
  RESIDENT: 'resident',
  CO_RESIDENT: 'co_resident',
  NEIGHBOR: 'neighbor',
  OBSERVER: 'observer',
} as const;

export const NOTIFICATION_TYPES = {
  EVENT_CREATED: 'event_created',
  EVENT_RESOLVED: 'event_resolved',
  EVENT_COMMENTED: 'event_commented',
  CIRCLE_INVITATION: 'circle_invitation',
  MEMBER_ADDED: 'member_added',
} as const;

export const UI_CONFIG = {
  MAX_FILE_SIZE: 50 * 1024 * 1024, // 50MB
  ALLOWED_VIDEO_TYPES: ['video/mp4', 'video/webm', 'video/quicktime'],
  NOTIFICATION_DISPLAY_TIME: 5000,
  DEBOUNCE_DELAY: 300,
  PAGINATION_DEFAULT_LIMIT: 20,
} as const;

export const ERROR_MESSAGES = {
  GENERIC: 'An error occurred. Please try again.',
  NETWORK: 'Network error. Please check your connection.',
  UNAUTHORIZED: 'You are not authorized to perform this action.',
  NOT_FOUND: 'The requested resource was not found.',
  FILE_TOO_LARGE: 'File size exceeds the maximum allowed size.',
  INVALID_FILE_TYPE: 'Invalid file type. Please upload a video file.',
} as const;

export const SUCCESS_MESSAGES = {
  EVENT_CREATED: 'Event created successfully',
  EVENT_UPDATED: 'Event updated successfully',
  EVENT_RESOLVED: 'Event resolved successfully',
  COMMENT_ADDED: 'Comment added successfully',
  MEMBER_ADDED: 'Member added successfully',
  MEMBER_REMOVED: 'Member removed successfully',
  NOTIFICATION_MARKED_READ: 'Notification marked as read',
} as const;
