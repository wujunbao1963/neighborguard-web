/**
 * Shared TypeScript types and interfaces
 */

// ============ Enums ============

export type EventSeverity = 'low' | 'medium' | 'high';
export type EventStatus = 'open' | 'resolved';
export type EventCreatorRole = 'owner' | 'resident' | 'neighbor' | 'observer' | 'unknown';
export type CircleMemberRole = 'owner' | 'resident' | 'neighbor' | 'observer';

// ============ API Response Types ============

export interface CircleSummary {
  id: string;
  name: string;
  address?: string;
  role: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface EventResponse {
  id: string;
  circleId: string;
  circleName?: string;
  cameraZone: string;
  eventType: string;
  requestText: string;
  title?: string;
  description?: string;
  severity: EventSeverity;
  status: EventStatus;
  occurredAt?: string;
  createdAt: string;
  updatedAt: string;
  videoAssetId?: string;
  videoUrl?: string;
  createdById?: string;
  createdByName?: string;
  createdByEmail?: string;
  createdByRole?: EventCreatorRole;
  isMine: boolean;
  myRoleInCircle: EventCreatorRole;
  canEditEvent: boolean;
  canChangeResolution: boolean;
  resolution?: string;
  resolutionNote?: string;
}

export interface NotificationResponse {
  id: string;
  type: string;
  payload: Record<string, unknown>;
  isRead: boolean;
  createdAt: string;
  userId?: string;
}

export interface HomeTasksResponse {
  inboxNewEvents: EventResponse[];
  inboxNotifications: NotificationResponse[];
  pendingEvents: EventResponse[];
  myCircles: CircleSummary[];
}

export interface MeResponse {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  circles: Array<{
    id: string;
    name: string;
    address?: string;
    role?: string;
  }>;
}

export interface CircleMemberResponse {
  id: string;
  circleId: string;
  userId: string;
  userName: string;
  userEmail: string;
  role: CircleMemberRole;
  createdAt: string;
  updatedAt: string;
}

export interface EventCommentResponse {
  id: string;
  eventId: string;
  circleId: string;
  userId: string;
  userName: string;
  userEmail: string;
  body: string;
  type: string;
  createdAt: string;
}

export interface EventNoteResponse {
  id: string;
  eventId: string;
  circleId: string;
  userId: string;
  userName: string;
  userEmail: string;
  body: string;
  type: string;
  createdAt: string;
}

export interface UploadVideoResponse {
  videoAssetId: string;
  url: string;
}

// ============ Request Payload Types ============

export interface CreateEventPayload {
  circleId: string;
  eventType: string;
  cameraZone: string;
  requestText: string;
  title?: string;
  description?: string;
  severity?: EventSeverity;
  occurredAt?: string;
  videoAssetId?: string;
}

export interface UpdateEventStatusPayload {
  status?: EventStatus;
  resolution?: string;
}

export interface AddCircleMemberPayload {
  email: string;
  name?: string;
  role?: CircleMemberRole;
}

export interface CreateEventCommentPayload {
  body: string;
  type?: string;
}

export interface CreateEventNotePayload {
  body: string;
  type?: string;
}

// ============ UI State Types ============

export type LoadingState = 'idle' | 'loading' | 'success' | 'error';

export interface ApiError {
  message: string;
  statusCode?: number;
  errorCode?: string;
}

export interface PaginationState {
  page: number;
  limit: number;
  total?: number;
  hasMore: boolean;
}

// ============ Dev User Types ============

export interface DevUser {
  id: string;
  name: string;
  email: string;
}

// ============ Form State Types ============

export interface CreateEventFormData {
  circleId: string;
  eventType: string;
  cameraZone: string;
  severity: EventSeverity;
  requestText: string;
  title?: string;
  description?: string;
  videoFile?: File;
}

export interface UpdateEventFormData {
  status: EventStatus;
  resolution: string;
}
